/* 64-bit multiplication and division
   Copyright (C) 1989, 1992-1999, 2000, 2001, 2002, 2003
   Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include "longlong.h"

#define W_TYPE_SIZE (sizeof(long))

#ifdef __ARMEB__
struct DWstruct {
	long high, low;
};
#else
struct DWstruct {
	long low, high;
};
#endif

typedef union {
	struct DWstruct s;
	long long ll;
} DWunion;

/* Prototypes of exported functions.  */
long long __divdi3(long long u, long long v);
long long __moddi3(long long u, long long v);
unsigned long long __udivdi3(unsigned long long u, unsigned long long v);
unsigned long long __umoddi3(unsigned long long u, unsigned long long v);

static unsigned long long
__udivmoddi4(unsigned long long n, unsigned long long d, unsigned long long *rp)
{
	DWunion ww;
	DWunion nn, dd;
	DWunion rr;
	unsigned long d0, d1, n0, n1, n2;
	unsigned long q0, q1;
	unsigned long b, bm;

	nn.ll = n;
	dd.ll = d;

	d0 = dd.s.low;
	d1 = dd.s.high;
	n0 = nn.s.low;
	n1 = nn.s.high;

#if !UDIV_NEEDS_NORMALIZATION
	if (d1 == 0) {
		if (d0 > n1) {
			/* 0q = nn / 0D */

			udiv_qrnnd(q0, n0, n1, n0, d0);
			q1 = 0;

			/* Remainder in n0.  */
		} else {
			/* qq = NN / 0d */

			if (d0 == 0)
				d0 = 1 / d0;	/* Divide intentionally by zero.  */

			udiv_qrnnd(q1, n1, 0, n1, d0);
			udiv_qrnnd(q0, n0, n1, n0, d0);

			/* Remainder in n0.  */
		}

		if (rp != 0) {
			rr.s.low = n0;
			rr.s.high = 0;
			*rp = rr.ll;
		}
	}
#else /* UDIV_NEEDS_NORMALIZATION */

	if (d1 == 0) {
		if (d0 > n1) {
			/* 0q = nn / 0D */

			count_leading_zeros(bm, d0);

			if (bm != 0) {
				/* Normalize, i.e. make the most significant bit of the
				   denominator set.  */

				d0 = d0 << bm;
				n1 = (n1 << bm) | (n0 >> (W_TYPE_SIZE - bm));
				n0 = n0 << bm;
			}

			udiv_qrnnd(q0, n0, n1, n0, d0);
			q1 = 0;

			/* Remainder in n0 >> bm.  */
		} else {
			/* qq = NN / 0d */

			if (d0 == 0)
				d0 = 1 / d0;	/* Divide intentionally by zero.  */

			count_leading_zeros(bm, d0);

			if (bm == 0) {
				/* From (n1 >= d0) /\ (the most significant bit of d0 is set),
				   conclude (the most significant bit of n1 is set) /\ (the
				   leading quotient digit q1 = 1).

				   This special case is necessary, not an optimization.
				   (Shifts counts of W_TYPE_SIZE are undefined.)  */

				n1 -= d0;
				q1 = 1;
			} else {
				/* Normalize.  */

				b = W_TYPE_SIZE - bm;

				d0 = d0 << bm;
				n2 = n1 >> b;
				n1 = (n1 << bm) | (n0 >> b);
				n0 = n0 << bm;

				udiv_qrnnd(q1, n1, n2, n1, d0);
			}

			/* n1 != d0...  */

			udiv_qrnnd(q0, n0, n1, n0, d0);

			/* Remainder in n0 >> bm.  */
		}

		if (rp != 0) {
			rr.s.low = n0 >> bm;
			rr.s.high = 0;
			*rp = rr.ll;
		}
	}
#endif /* UDIV_NEEDS_NORMALIZATION */

	else {
		if (d1 > n1) {
			/* 00 = nn / DD */

			q0 = 0;
			q1 = 0;

			/* Remainder in n1n0.  */
			if (rp != 0) {
				rr.s.low = n0;
				rr.s.high = n1;
				*rp = rr.ll;
			}
		} else {
			/* 0q = NN / dd */

			count_leading_zeros(bm, d1);
			if (bm == 0) {
				/* From (n1 >= d1) /\ (the most significant bit of d1 is set),
				   conclude (the most significant bit of n1 is set) /\ (the
				   quotient digit q0 = 0 or 1).

				   This special case is necessary, not an optimization.  */

				/* The condition on the next line takes advantage of that
				   n1 >= d1 (true due to program flow).  */
				if (n1 > d1 || n0 >= d0) {
					q0 = 1;
					sub_ddmmss(n1, n0, n1, n0, d1, d0);
				} else
					q0 = 0;

				q1 = 0;

				if (rp != 0) {
					rr.s.low = n0;
					rr.s.high = n1;
					*rp = rr.ll;
				}
			} else {
				unsigned long m1, m0;
				/* Normalize.  */

				b = W_TYPE_SIZE - bm;

				d1 = (d1 << bm) | (d0 >> b);
				d0 = d0 << bm;
				n2 = n1 >> b;
				n1 = (n1 << bm) | (n0 >> b);
				n0 = n0 << bm;

				udiv_qrnnd(q0, n1, n2, n1, d1);
				umul_ppmm(m1, m0, q0, d0);

				if (m1 > n1 || (m1 == n1 && m0 > n0)) {
					q0--;
					sub_ddmmss(m1, m0, m1, m0, d1, d0);
				}

				q1 = 0;

				/* Remainder in (n1n0 - m1m0) >> bm.  */
				if (rp != 0) {
					sub_ddmmss(n1, n0, n1, n0, m1, m0);
					rr.s.low = (n1 << b) | (n0 >> bm);
					rr.s.high = n1 >> bm;
					*rp = rr.ll;
				}
			}
		}
	}

	ww.s.low = q0;
	ww.s.high = q1;
	return ww.ll;
}

long long __divdi3(long long u, long long v)
{
	long c = 0;
	long long w;

	if (u < 0) {
		c = ~c;
		u = -u;
	}
	if (v < 0) {
		c = ~c;
		v = -v;
	}
	w = __udivmoddi4(u, v, 0);
	if (c)
		w = -w;
	return w;
}

long long __moddi3(long long u, long long v)
{
	long c = 0;
	long long w;

	if (u < 0) {
		c = ~c;
		u = -u;
	}
	if (v < 0)
		v = -v;
	__udivmoddi4(u, v, &w);
	if (c)
		w = -w;
	return w;
}

unsigned long long __udivdi3(unsigned long long u, unsigned long long v)
{
	return __udivmoddi4(u, v, 0);
}

unsigned long long __umoddi3(unsigned long long u, unsigned long long v)
{
	unsigned long long w;

	__udivmoddi4(u, v, &w);
	return w;
}

long long __gnu_ldivmod_helper(long long a, long long b, long long *remainder)
{
	long long quotient;

	quotient = __divdi3(a, b);
	*remainder = a - b * quotient;

	return quotient;
}

unsigned long long

__gnu_uldivmod_helper(unsigned long long a,
		      unsigned long long b, unsigned long long *remainder)
{
	unsigned long long quotient;

	quotient = __udivdi3(a, b);
	*remainder = a - b * quotient;
	return quotient;
}
