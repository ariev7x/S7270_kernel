#ifndef __ASM_ARM_EXEC_H
#define __ASM_ARM_EXEC_H

#define arch_align_stack(x) (x)

#endif /* __ASM_ARM_EXEC_H */
